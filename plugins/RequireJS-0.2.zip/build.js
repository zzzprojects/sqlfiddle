({
    appDir: "../../javascripts",
    baseUrl: ".",
    dir: "../../javascripts_min",
	mainConfigFile: "../../javascripts/main.js",
    modules: [
        {
            name: "main"
        }
    ]
})